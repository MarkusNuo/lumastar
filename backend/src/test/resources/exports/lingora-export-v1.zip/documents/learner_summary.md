# Lernstand Erza – 05.10.2026 (Gheg, Kosovo)
Ich spreche Deutsch und lerne Gheg-Albanisch (Kosovo). Bitte antworte auf Deutsch und verwende auf Albanisch nur Gheg-Formen, keine Standard-Formen (z. B. *âsht* statt *është*).

- Niveau: A1.2 (Ziel C2), 3 Tage Streak, 6 Wörter
- Aktuelle Einheit: noch keine
- Stärken: noch keine
- Schwächen: Begrüssung 68 %
- Häufige Fehler (30 Tage): Wort nicht gewusst 1×
- Letzte typische Fehler:
  - Aufgabe „Wie geht es dir?“: „si jeni“ → „Si je?“ (Wort nicht gewusst)
